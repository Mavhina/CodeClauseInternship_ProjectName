import code.clause.CalcTypes.ScientificCalculator;
import code.clause.CalcTypes.StandardCalc;
import code.clause.CalcTypes.UnitConverter;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 300, 400);

        // Menu bar
        MenuBar menuBar = new MenuBar();
        Menu calculatorMenu = new Menu("Calculator Type");

        // Calculator types
        MenuItem scientificItem = new MenuItem("Scientific");
        MenuItem standardItem = new MenuItem("Standard");
        MenuItem conversionItem = new MenuItem("Unit Conversion");
        MenuItem exitItem = new MenuItem("Exit");

        // Add event handlers for menu items
        scientificItem.setOnAction(e -> setCalculatorType("Scientific", primaryStage));
        standardItem.setOnAction(e -> setCalculatorType("Standard", primaryStage));
        conversionItem.setOnAction(e -> setCalculatorType("Unit Conversion", primaryStage));
        exitItem.setOnAction(e -> System.exit(0));

        // Add items to the menu
        calculatorMenu.getItems().addAll(scientificItem, standardItem, conversionItem, new SeparatorMenuItem(), exitItem);
        menuBar.getMenus().add(calculatorMenu);

        // Text area for display
        TextArea displayArea = new TextArea();
        displayArea.setEditable(false);
        borderPane.setTop(menuBar);
        borderPane.setCenter(displayArea);

        primaryStage.setTitle("JavaFX Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void setCalculatorType(String calculatorType, Stage primaryStage) {
        switch (calculatorType) {
            case "Scientific":
                ScientificCalculator scientificCalculator = new ScientificCalculator();
                scientificCalculator.start(primaryStage);
                break;
            case "Standard":
                StandardCalc standardCalc = new StandardCalc();
                standardCalc.start(primaryStage);
                break;
            case "Unit Conversion":
                UnitConverter unitConverter = new UnitConverter();
                unitConverter.start(primaryStage);
                break;
            default:
                break;
        }
    }

}
