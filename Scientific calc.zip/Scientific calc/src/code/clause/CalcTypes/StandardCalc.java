package code.clause.CalcTypes;

import java.math.BigDecimal;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class StandardCalc extends Application {

    private TextField display;
    private BigDecimal num1 = BigDecimal.ZERO;
    private String operator = "";
    private boolean start = true;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Standard Calculator");

        // Create the display
        display = new TextField();
        display.setPromptText("0");
        display.setEditable(false);
        display.setAlignment(Pos.CENTER_RIGHT);
        display.setStyle("-fx-font-size: 18; -fx-font-weight: bold;");
        display.setMinSize(280, 50);

        // Create number buttons
        Button[] numberButtons = new Button[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = createNumberButton(Integer.toString(i));
        }

        // Create operator buttons
        Button addButton = createOperatorButton("+");
        Button subtractButton = createOperatorButton("-");
        Button multiplyButton = createOperatorButton("*");
        Button divideButton = createOperatorButton("/");

        // Create other buttons
        Button clearButton = createButton("C");
        Button equalsButton = createButton("=");

        // Layout setup
        GridPane buttonGrid = new GridPane();
        buttonGrid.setAlignment(Pos.CENTER);
        buttonGrid.setHgap(10);
        buttonGrid.setVgap(10);

        // Add number buttons to the grid
        for (int i = 1; i <= 9; i++) {
            buttonGrid.add(numberButtons[i], (i - 1) % 3, (i - 1) / 3 + 1);
        }
        buttonGrid.add(numberButtons[0], 0, 4, 2, 1); // Number 0 button

        buttonGrid.add(divideButton, 3, 1);
        buttonGrid.add(multiplyButton, 3, 2);
        buttonGrid.add(subtractButton, 3, 3);
        buttonGrid.add(clearButton, 1, 4);
        buttonGrid.add(equalsButton, 2, 4);
        buttonGrid.add(addButton, 3, 4);

        // BorderPane for frame
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(display);
        borderPane.setCenter(buttonGrid);
        borderPane.setStyle("-fx-padding: 10; -fx-border-color: black; -fx-border-width: 2;");

        // Scene setup
        Scene scene = new Scene(borderPane, 420, 480);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    private Button createOperatorButton(String operator) {
        Button button = createButton(operator);
        button.setStyle("-fx-font-size: 14;");
        button.setOnAction(e -> handleOperator(operator));
        return button;
    }

    private Button createNumberButton(String label) {
        Button button = createButton(label);
        button.setStyle("-fx-font-size: 18; -fx-font-weight: bold;");
        button.setOnAction(e -> appendDigit(new BigDecimal(label)));
        return button;
    }

    private Button createButton(String label) {
        Button button = new Button(label);
        button.setMinSize(70, 70);
        button.setStyle("-fx-font-size: 18; -fx-font-weight: bold;");
        button.setOnAction(e -> handleButtonClick(label));
        return button;
    }

    private void appendDigit(BigDecimal digit) {
        if (start || display.getText().equals("0")) {
            display.clear();
            start = false;
        }
        display.appendText(digit.stripTrailingZeros().toPlainString());
    }

    private void handleOperator(String op) {
        if (!start) {
            num1 = new BigDecimal(display.getText()); // Update num1 to the current value in the display
            start = true;
            operator = op;
        }
    }


    private void handleButtonClick(String buttonLabel) {
        switch (buttonLabel) {
            case "C":
                clear();
                break;
            case "=":
                calculate();
                start = true;
                break;
            default:
                appendDigit(new BigDecimal(buttonLabel));
                break;
        }
    }

    private void clear() {
        display.clear();
        num1 = BigDecimal.ZERO;
        operator = "";
        start = true;
    }

    private void calculate() {
        if (!operator.isEmpty()) {
            BigDecimal num2 = new BigDecimal(display.getText());
            switch (operator) {
                case "+":
                    num1 = num1.add(num2);
                    break;
                case "-":
                    num1 = num1.subtract(num2);
                    break;
                case "*":
                    num1 = num1.multiply(num2);
                    break;
                case "/":
                    if (!num2.equals(BigDecimal.ZERO)) {
                        num1 = num1.divide(num2, 10, BigDecimal.ROUND_HALF_UP);
                    } else {
                        display.setText("Error");
                        clear();
                        return;
                    }
                    break;
            }
            display.setText(num1.stripTrailingZeros().toPlainString());
        }
    }
}
