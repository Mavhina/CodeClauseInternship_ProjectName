package code.clause.CalcTypes;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class UnitConverter extends Application {

    private TextField inputField;
    private Label resultLabel;
    private ComboBox<String> fromUnitComboBox; // Declare as instance variable
    private ComboBox<String> toUnitComboBox;   // Declare as instance variable

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Unit Converter");

        inputField = new TextField();
        inputField.setPromptText("Enter value");

        resultLabel = new Label("Result: ");

        fromUnitComboBox = new ComboBox<>(); // Initialize instance variable
        fromUnitComboBox.getItems().addAll("Meters", "Kilometers", "Centimeters", "Millimeters", "Feet", "Inches");
        fromUnitComboBox.setValue("Meters");

        toUnitComboBox = new ComboBox<>();   // Initialize instance variable
        toUnitComboBox.getItems().addAll("Meters", "Kilometers", "Centimeters", "Millimeters", "Feet", "Inches");
        toUnitComboBox.setValue("Meters");

        Button convertButton = new Button("Convert");
        convertButton.setOnAction(e -> convertUnits());

        // Layout setup
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);

        grid.add(new Label("From:"), 0, 0);
        grid.add(inputField, 1, 0);
        grid.add(fromUnitComboBox, 2, 0);
        grid.add(new Label("To:"), 0, 1);
        grid.add(resultLabel, 1, 1);
        grid.add(toUnitComboBox, 2, 1);
        grid.add(convertButton, 1, 2);

        Scene scene = new Scene(grid, 300, 200);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    private void convertUnits() {
        try {
            double inputValue = Double.parseDouble(inputField.getText());
            String fromUnit = fromUnitComboBox.getValue();
            String toUnit = toUnitComboBox.getValue();

            double result = convert(inputValue, fromUnit, toUnit);
            resultLabel.setText("Result: " + result + " " + toUnit);
        } catch (NumberFormatException e) {
            resultLabel.setText("Invalid input");
        }
    }

    private double convert(double value, String fromUnit, String toUnit) {
        // Conversion logic
        switch (fromUnit) {
            case "Meters":
                switch (toUnit) {
                    case "Kilometers":
                        return value * 0.001;
                    case "Centimeters":
                        return value * 100;
                    case "Millimeters":
                        return value * 1000;
                    case "Feet":
                        return value * 3.28084;
                    case "Inches":
                        return value * 39.3701;
                    default:
                        return value;
                }
            case "Kilometers":
                switch (toUnit) {
                    case "Meters":
                        return value * 1000;
                    case "Centimeters":
                        return value * 100000;
                    case "Millimeters":
                        return value * 1000000;
                    case "Feet":
                        return value * 3280.84;
                    case "Inches":
                        return value * 39370.1;
                    default:
                        return value;
                }
            case "Centimeters":
                switch (toUnit) {
                    case "Meters":
                        return value * 0.01;
                    case "Kilometers":
                        return value * 0.00001;
                    case "Millimeters":
                        return value * 10;
                    case "Feet":
                        return value * 0.0328084;
                    case "Inches":
                        return value * 0.393701;
                    default:
                        return value;
                }
            case "Millimeters":
                switch (toUnit) {
                    case "Meters":
                        return value * 0.001;
                    case "Kilometers":
                        return value * 0.000001;
                    case "Centimeters":
                        return value * 0.1;
                    case "Feet":
                        return value * 0.00328084;
                    case "Inches":
                        return value * 0.0393701;
                    default:
                        return value;
                }
            case "Feet":
                switch (toUnit) {
                    case "Meters":
                        return value * 0.3048;
                    case "Kilometers":
                        return value * 0.0003048;
                    case "Centimeters":
                        return value * 30.48;
                    case "Millimeters":
                        return value * 304.8;
                    case "Inches":
                        return value * 12;
                    default:
                        return value;
                }
            case "Inches":
                switch (toUnit) {
                    case "Meters":
                        return value * 0.0254;
                    case "Kilometers":
                        return value * 0.0000254;
                    case "Centimeters":
                        return value * 2.54;
                    case "Millimeters":
                        return value * 25.4;
                    case "Feet":
                        return value * 0.0833333;
                    default:
                        return value;
                }
            default:
                return value;
        }
    }
}
