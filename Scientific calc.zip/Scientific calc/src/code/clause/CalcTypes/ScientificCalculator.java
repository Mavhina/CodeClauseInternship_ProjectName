package code.clause.CalcTypes;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ScientificCalculator extends Application {

    private TextField display;
    private String currentInput = "";
    private boolean start = true;
    private double storedOperand = 0;
    private String currentOperation = "";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Scientific Calculator");

        display = new TextField();
        display.setPromptText("0");
        display.setEditable(false);
        display.setAlignment(Pos.CENTER_RIGHT);
        display.setStyle("-fx-font-size: 18; -fx-control-inner-background: white;");
        display.setMinSize(280, 50);

        Label outputLabel = new Label();
        outputLabel.setStyle("-fx-font-size: 14; -fx-border-color: black; -fx-border-width: 1;");
        outputLabel.setMinSize(280, 30);
        outputLabel.setAlignment(Pos.CENTER_RIGHT);

        Button[] numberButtons = new Button[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = createNumberButton(Integer.toString(i));
        }

        Button dotButton = createButton(".");
        Button clearButton = createButton("C");
        Button equalsButton = createButton("=");
        Button addButton = createButton("+");
        Button subtractButton = createButton("-");
        Button multiplyButton = createButton("*");
        Button divideButton = createButton("/");
        Button sqrtButton = createButton("sqrt");
        Button powerButton = createButton("^");
        Button sinButton = createButton("sin");
        Button cosButton = createButton("cos");
        Button tanButton = createButton("tan");

        GridPane buttonGrid = new GridPane();
        buttonGrid.setAlignment(Pos.CENTER);
        buttonGrid.setHgap(10);
        buttonGrid.setVgap(10);

        buttonGrid.add(numberButtons[7], 0, 0);
        buttonGrid.add(numberButtons[8], 1, 0);
        buttonGrid.add(numberButtons[9], 2, 0);
        buttonGrid.add(divideButton, 3, 0);

        buttonGrid.add(numberButtons[4], 0, 1);
        buttonGrid.add(numberButtons[5], 1, 1);
        buttonGrid.add(numberButtons[6], 2, 1);
        buttonGrid.add(multiplyButton, 3, 1);

        buttonGrid.add(numberButtons[1], 0, 2);
        buttonGrid.add(numberButtons[2], 1, 2);
        buttonGrid.add(numberButtons[3], 2, 2);
        buttonGrid.add(subtractButton, 3, 2);

        buttonGrid.add(numberButtons[0], 0, 3);
        buttonGrid.add(dotButton, 1, 3);
        buttonGrid.add(equalsButton, 2, 3);
        buttonGrid.add(addButton, 3, 3);

        buttonGrid.add(clearButton, 0, 4);
        buttonGrid.add(sqrtButton, 1, 4);
        buttonGrid.add(powerButton, 2, 4);
        buttonGrid.add(sinButton, 3, 4);

        buttonGrid.add(cosButton, 0, 5);
        buttonGrid.add(tanButton, 1, 5);

        VBox vBox = new VBox(10);
        vBox.setAlignment(Pos.CENTER);
        vBox.getChildren().addAll(display, outputLabel, buttonGrid);

        Scene scene = new Scene(vBox, 420, 550); // Increased height for the output bar
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    private Button createButton(String label) {
        Button button = new Button(label);
        button.setMinSize(70, 70);
        button.setStyle("-fx-font-size: 14;");
        button.setOnAction(e -> handleButtonClick(label));
        return button;
    }

    private Button createNumberButton(String label) {
        Button button = createButton(label);
        button.setStyle("-fx-font-size: 18;");
        button.setOnAction(e -> appendDigit(label));
        return button;
    }

    private void appendDigit(String digit) {
        if (start) {
            display.clear();
            start = false;
        }
        currentInput += digit;
        display.setText(currentInput);
    }

    private void handleButtonClick(String buttonLabel) {
        switch (buttonLabel) {
            case "C":
                clear();
                break;
            case "=":
                calculate();
                start = true;
                break;
            case "sqrt":
                handleUnaryOperation("sqrt");
                break;
            case "^":
                handleBinaryOperation("^");
                break;
            case "sin":
                handleUnaryOperation("sin");
                break;
            case "cos":
                handleUnaryOperation("cos");
                break;
            case "tan":
                handleUnaryOperation("tan");
                break;
            default:
                appendDigit(buttonLabel);
                break;
        }
    }

    private void handleUnaryOperation(String operation) {
        if (!start) {
            double operand = Double.parseDouble(currentInput);
            double result = 0;
            switch (operation) {
                case "sqrt":
                    result = Math.sqrt(operand);
                    break;
                case "sin":
                    result = Math.sin(Math.toRadians(operand));
                    break;
                case "cos":
                    result = Math.cos(Math.toRadians(operand));
                    break;
                case "tan":
                    result = Math.tan(Math.toRadians(operand));
                    break;
            }
            display.setText(String.valueOf(result));
            currentInput = String.valueOf(result);
            start = true;
        }
    }

 

    private void clear() {
        display.clear();
        currentInput = "";
        start = true;
        storedOperand = 0;
        currentOperation = "";
    }

    private void handleBinaryOperation(String operation) {
        if (!start) {
            storedOperand = Double.parseDouble(currentInput);
            currentOperation = operation;
            start = true;
            currentInput = "";  // Clear currentInput for the second operand
        }
    }

    private void calculate() {
        if (!start) {
            try {
                double operand2 = Double.parseDouble(currentInput);

                // Perform the calculation based on the stored operation (if any)
                double result = 0;
                switch (currentOperation) {
                    case "+":
                        result = storedOperand + operand2;
                        break;
                    case "-":
                        result = storedOperand - operand2;
                        break;
                    case "*":
                        result = storedOperand * operand2;
                        break;
                    case "/":
                        if (operand2 != 0) {
                            result = storedOperand / operand2;
                        } else {
                            display.setText("Error");
                            clear();
                            return;
                        }
                        break;
                    case "^":
                        result = Math.pow(storedOperand, operand2);
                        break;
                    default:
                        // No operation to perform
                        return;
                }

                display.setText(String.valueOf(result));
                currentInput = String.valueOf(result);
                start = true;
                storedOperand = 0; // Reset stored operand
                currentOperation = ""; // Reset current operation
            } catch (NumberFormatException e) {
                display.setText("Error");
                clear();
            }
        }
    }

}
